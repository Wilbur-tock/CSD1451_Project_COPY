#include "Color.hpp"

Color::Color() {
	SetColor(0, 0, 0, 0);
}
Color::Color(float _r, float _g, float _b, float _a) {
	SetColor(_r, _g, _b, _a);
}

void Color::SetColor(float _r, float _g, float _b, float _a) {
	r = _r < min ? min : _r > max ? max : _r;
	g = _g < min ? min : _g > max ? max : _g;
	b = _b < min ? min : _b > max ? max : _b;
	a = _a < min ? min : _a > max ? max : _a;
}

void Color::EditColorPercentage(float percentage) {
	SetColor(
		r *= percentage,
		g *= percentage,
		b *= percentage
	);
}

float Color::Red() const { return r;}

float Color::Green() const { return g; }

float Color::Blue() const { return b;}

float Color::Alpha() const { return a; }